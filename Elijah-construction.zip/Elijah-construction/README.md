# Elijah-construction

A responsive static website for Nasasira Elijah — construction, civil engineering and plumbing services.

## Files
- `index.html` — website structure and content
- `style.css` — responsive layout and color theme

## Color theme
- Deep construction navy: `#10283f`
- Secondary steel blue: `#183b56`
- Safety orange accent: `#e97832`
- Warm concrete background: `#f4f1e9`
- Clean white: `#fffefa`

## Preview locally
Open `index.html` in a browser, or use the Live Server extension in Visual Studio Code.

## Publish with GitHub Pages
1. Open your GitHub repository for `Elijah-construction`.
2. Upload the contents of this folder (not the ZIP file) to the repository root.
3. Commit the changes to the branch configured for GitHub Pages.
4. Refresh https://breezy-barham.github.io/Elijah-construction/

The WhatsApp buttons use the contact numbers already displayed on the website.
